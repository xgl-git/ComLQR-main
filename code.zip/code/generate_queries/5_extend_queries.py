import json
import os
import csv
import openai
client = openai.OpenAI(api_key= "kw-yaIRae0YPWIBPqIpiOALGU5NuoDBXPdIrsaGkQ6kEF635nus", base_url='http://10.88.3.81:8502')
base_dir = 'data'
def call_open(input_prompt):
    request_params = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system",
             "content": "You are a helpful assistant. Make sure you carefully and fully understand the details of user's requirements before you start solving the problem."},
            {"role": "user", "content": input_prompt},
        ],
    }
    response = client.chat.completions.create(**request_params)
    response = response.model_dump()
    generated_text = response['choices'][0]['message']['content'].strip()
    return generated_text

base_dir = './dataset'

type2qid = {}
new_cids = 0
with open(os.path.join(base_dir, 'queries.jsonl'), 'r', encoding = 'utf-8') as f:
    for line in f.readlines():
        data = json.loads(line)
        type = data['type'].split('_')[0]
        if type not in type2qid:
            type2qid[type] = []
            type2qid[type].append(data['_id'])
        else:
            type2qid[type].append(data['_id'])
        new_cids += 1

qid2cid = {}
with open(os.path.join(base_dir, 'qrels', 'test.tsv'), 'r', newline='', encoding='utf-8') as file:
    csv_reader = csv.reader(file, delimiter='\t')
    header = next(csv_reader)
    for row in csv_reader:
        qid, cid, score = row
        if qid not in qid2cid:
            qid2cid[qid] = []
            qid2cid[qid].append(cid)
        else:
            qid2cid[qid].append(cid)
count1 = 0
count2 = 0
count3 = 0
for qid in qid2cid:
    # print(len(qid2cid[qid]))
    if len(qid2cid[qid]) == 1:
        count1 += 1
    if len(qid2cid[qid]) == 2:
        count2 += 1
    if len(qid2cid[qid]) == 3:
        count3 += 1
print(count1, count2, count3)
corpus = {}
with open(os.path.join(base_dir, 'corpus.jsonl'), 'r', encoding = 'utf-8') as f:
    for line in f.readlines():
        data = json.loads(line)
        corpus[data['_id']] = data['text']

import random
random.seed(1)
prompts_1 = ['prompt_1p.txt', 'prompt_2i_1.txt', 'prompt_2p_1.txt', 'prompt_2u_1.txt', 'prompt_3i_1.txt', 'prompt_3in_1.txt', 'prompt_3p_1.txt','prompt_inp_1.txt',
            'prompt_ip_1.txt', 'prompt_pi_1.txt', 'prompt_pin_1.txt', 'prompt_pni_1.txt', 'prompt_up_1.txt', 'prompt_2in_1.txt']
prompts_2 = ['prompt_2i_2.txt', 'prompt_2in_2.txt', 'prompt_2p_2.txt', 'prompt_2u_2.txt', 'prompt_3i_2.txt', 'prompt_3in_2.txt',
             'prompt_3p_2.txt', 'prompt_inp_2.txt', 'prompt_ip_2.txt', 'prompt_pi_2.txt', 'prompt_pin_2.txt', 'prompt_pni_2.txt', 'prompt_up_2.txt']
prompts_3 = ['prompt_3i_3.txt', 'prompt_3in_3.txt', 'prompt_3p_3.txt', 'prompt_inp_3.txt', 'prompt_pin_3.txt', 'prompt_pni_3.txt']
base_dir = './addition_queries'
file_cids = [int(file.split('_')[0]) for file in os.listdir(base_dir)]
if len(file_cids) != 0:
    new_cids = max([int(file.split('_')[0]) for file in os.listdir(base_dir)]) + 1
count = 0
for type in type2qid:
    num = int(len(type2qid[type])/40)
    qids = random.sample(type2qid[type], num)
    for qid in qids:
        cids = qid2cid[qid]
        num_cid = len(cids)
        if num_cid == 1:
            passage = corpus[cids[0]].strip()
            for prompt in prompts_1:
                input_prompt = open(prompt, 'r', encoding = 'utf-8').read().replace('[[PASSAGE]]', passage)
                type_ = prompt.split('_')[1]
                if type_ == '1p.txt':
                    type_ = '1p'
                generated_text = call_open(input_prompt)
                with open('./addition_queries/{}_{}_{}.txt'.format(new_cids, cids[0], type_), 'w', encoding='utf-8') as f:
                    f.write(generated_text)
                new_cids += 1
                count += 1
        if num_cid == 2:
            for prompt in prompts_2:
                passage1 = corpus[cids[0]].strip()
                passage2 = corpus[cids[1]].strip()
                passage = "passage 1: " + passage1 + "\n" + "passage 2: " + passage2
                input_prompt = open(prompt, 'r', encoding='utf-8').read().replace('[[PASSAGE]]', passage)
                type_ = prompt.split('_')[1]
                generated_text = call_open(input_prompt)
                with open('./addition_queries/{}_{}_{}_{}.txt'.format(new_cids, cids[0], cids[1], type_), 'w', encoding='utf-8') as f:
                    f.write(generated_text)
                new_cids += 1
                count += 1
        if num_cid == 3:
            for prompt in prompts_3:
                passage1 = corpus[cids[0]].strip()
                passage2 = corpus[cids[1]].strip()
                passage3 = corpus[cids[2]].strip()
                passage = "passage 1: " + passage1 + "\n" + "passage 2: " + passage2 + "\n" + "passage 3: " + passage3
                input_prompt = open(prompt, 'r', encoding='utf-8').read().replace('[[PASSAGE]]', passage)
                type_ = prompt.split('_')[1]
                generated_text = call_open(input_prompt)
                with open('./addition_queries/{}_{}_{}_{}_{}.txt'.format(new_cids, cids[0], cids[1], cids[2], type_), 'w',
                          encoding='utf-8') as f:
                    f.write(generated_text)
                new_cids += 1
                count += 1
'''
1. 读取queries.jsonl
type2qid = {"1p":[], "2p":[]...} (不用区分那么细)
2. 读取test.tsv
qid2cid = {"1637": [12492, 12493, 12494]...}
3. 读取corpus.jsonl
dorpus = {cid: text}
4. 随机在每个类型中选择若干qid，然后根据qid2cid找到对应的几个cid
根据cid的数量判断需要调用的prompt
1: 调用所有类型的prompt
2: 调用除1p之外的prompt
3：调用3i, 3in, 3p, inp, pin, pni的prompt
5. 生成query，标记上对应的cid和type
'''