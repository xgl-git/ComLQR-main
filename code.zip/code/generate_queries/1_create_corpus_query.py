import os
import re
import json
import random
import csv
import shutil
import openai
# 删除目录及其所有内容

def extract_query_answer(text):
    query_pattern = re.search(r'Query:\s*(.*?)\n', text)
    answer_pattern = re.search(r'Answer:\s*(.*)', text)
    query = query_pattern.group(1) if query_pattern else None
    answer = answer_pattern.group(1) if answer_pattern else None
    return query, answer
q_c_pair = [['query-id', 'corpus-id', 'score']]
shutil.rmtree('./dataset')
os.makedirs('./dataset')
base_dir = './temp_data'
qid = 0
cid = 10000
for type in os.listdir(base_dir):
    type_ = type.split('_')
    type_path = os.path.join(base_dir, type)
    for _id in sorted([int(e) for e in os.listdir(type_path)]):
        id_path = os.path.join(type_path, str(_id))
        for file in os.listdir(id_path):
            file_path = os.path.join(id_path, file)
            content = open(file_path, 'r', encoding = 'utf-8').read()
            if file == 'query.txt':
                query, answer = extract_query_answer(content)
                if "**" in query:
                    print(id_path)
                with open('dataset/queries.jsonl', 'a', encoding='utf-8') as f:
                    data = {"_id": str(qid), "text": query.strip(), "answer": answer.strip(), "type": type}
                    json.dump(data, f, ensure_ascii = False)
                    f.write("\n")
            else:
                with open('dataset/corpus.jsonl', 'a', encoding='utf-8', ) as f:
                    data = {"_id": str(cid), "text": content.strip()}
                    json.dump(data, f, ensure_ascii = False)
                    f.write("\n")
                if len(type_) == 1:
                    q_c_pair.append([str(qid), str(cid), '2'])
                elif len(type_) == 2 and (type_[1] == '2' or type_[1] == '3'):
                    q_c_pair.append([str(qid), str(cid), '1'])
                elif len(type_) == 2 and type_[1] == '1':
                    q_c_pair.append([str(qid), str(cid), '2'])
                cid += 1
        qid += 1
with open('./data/data_20.json', 'r', encoding = 'utf-8') as f:
    data = json.load(f)
corpus = []
for key in data:
    for passage in data[key]:
        corpus.append(passage)
selected_passages = random.sample(corpus, 4000)
with open('./dataset/corpus.jsonl', 'a', encoding = 'utf-8') as f:
    for passage in selected_passages:
        data = {"_id": str(cid), "text": passage.strip()}
        json.dump(data, f, ensure_ascii = False)
        f.write('\n')
        cid += 1
qrels_path = './dataset/qrels/'
if not os.path.exists(qrels_path):
    os.makedirs(qrels_path)
with open(os.path.join(qrels_path, 'test.tsv'), 'a', newline='', encoding='utf-8') as file:
    writer = csv.writer(file, delimiter='\t')
    for row in q_c_pair:
        writer.writerow(row)