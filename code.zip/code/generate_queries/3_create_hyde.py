import os
import re
import openai
import json
client = openai.OpenAI(api_key= "kw-yaIRae0YPWIBPqIpiOALGU5NuoDBXPdIrsaGkQ6kEF635nus", base_url='http://10.88.3.81:8502')

prompt = """
    Please write a hypothetical passage to answer the question. The passage contains hallucinations and does not exceed 150 words.
    Question: [[QUESTION]]
    Passage:
"""
def extract_query_answer(text):
    query_pattern = re.search(r'Query:\s*(.*?)\n', text)
    answer_pattern = re.search(r'Answer:\s*(.*)', text)
    query = query_pattern.group(1) if query_pattern else None
    answer = answer_pattern.group(1) if answer_pattern else None
    return query, answer
def generate_hyde(input_prompt):
    request_params = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system",
             "content": "You are a helpful assistant. Make sure you carefully and fully understand the details of user's requirements before you start solving the problem."},
            {"role": "user", "content": input_prompt},
        ],
    }
    response = client.chat.completions.create(**request_params)
    response = response.model_dump()
    passage = response['choices'][0]['message']['content'].strip()
    return passage
cid = 0
hyds = []
with open('./hyde.jsonl', 'r', encoding='utf-8', ) as f:
    for line in f.readlines():
        data = json.loads(line)
        hyds.append(data['text'])
        cid += 1
file_path = './dataset/queries.jsonl'
count = 0
for line in open(file_path, 'r', encoding = 'utf-8').readlines():
    data = json.loads(line)
    query = data['text']
    type = data['type']
    if "pni" in type:
        input_prompt = prompt.replace("[[QUESTION]]", query)
        if count <= 100:
            count += 1
            continue
        hyde = generate_hyde(input_prompt)
        if hyde in hyds:
            continue
        print(hyde)
        hyds.append(hyde)
        with open('./hyde.jsonl', 'a', encoding='utf-8') as f:
            data = {"_id": str(cid), "text": hyde.strip(), "type": type}
            json.dump(data, f, ensure_ascii=False)
            f.write("\n")
            cid += 1