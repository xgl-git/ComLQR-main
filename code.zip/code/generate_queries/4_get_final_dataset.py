import json

cid = 10000
with open('dataset/corpus.jsonl', 'r', encoding='utf-8', ) as f:
    for line in f.readlines():
        cid += 1

with open('./hyde.jsonl', 'r', encoding='utf-8', ) as f:
    for line in f.readlines():
        data = json.loads(line)
        text = data['text']
        with open('dataset/corpus.jsonl', 'a', encoding='utf-8', ) as f:
            data = {"_id": str(cid), "text": text.strip()}
            json.dump(data, f, ensure_ascii=False)
            f.write("\n")
            cid += 1