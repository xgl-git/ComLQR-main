import csv
import json
import os
import openai
import re
client = openai.OpenAI(api_key= "", base_url='')
def call_open(input_prompt):
    request_params = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system",
             "content": "You are a helpful assistant. Make sure you carefully and fully understand the details of user's requirements before you start solving the problem."},
            {"role": "user", "content": input_prompt},
        ],
    }
    response = client.chat.completions.create(**request_params)
    response = response.model_dump()
    generated_text = response['choices'][0]['message']['content'].strip()
    return generated_text
def extract_query_answer(text):
    query_pattern = re.search(r'Query:\s*(.*?)\n', text)
    answer_pattern = re.search(r'Answer:\s*(.*)', text)

    query = query_pattern.group(1) if query_pattern else None
    answer = answer_pattern.group(1) if answer_pattern else None

    return query, answer

corpus = []
temp_data_dir = 'temp_data'
queries = []
for type in os.listdir(temp_data_dir):
    type_path = os.path.join(temp_data_dir, type)
    for _id in sorted([int(e) for e in os.listdir(type_path)]):
        id_path = os.path.join(type_path, str(_id))
        for file in os.listdir(id_path):
            file_path = os.path.join(id_path, file)
            content = open(file_path, 'r', encoding = 'utf-8').read().strip()
            if file != 'query.txt':
                corpus.append(content)
            if file == 'query.txt':
                query, answer = extract_query_answer(content)
                if query != None:
                    queries.append(query.strip())
type = "pin_2"
_id = 0
type_path = os.path.join(temp_data_dir, type)
num = len(os.listdir(type_path))
if num == 0:
    _id = 0
else:
    _id = max([int(e) for e in os.listdir(type_path)]) + 1
count = 0
base_dir = 'data'

file_path = os.path.join(base_dir, 'data_1.json')
with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)
prompt_pin = open('prompt_pin_2.txt', 'r', encoding ='utf-8').read()
for _key in data:
    if len(data[_key]) < 18:
        continue
    passage = "passage 1: "+data[_key][16].strip() +"\n" +"passage 2: "+ data[_key][17].strip()
    if data[_key][16].strip() in corpus or data[_key][17].strip() in corpus:
        continue
    input_prompt = prompt_pin.replace('[[PASSAGE]]', passage)
    generated_text = call_open(input_prompt)
    print(generated_text)
    query, answer= extract_query_answer(generated_text)
    if query == None or answer == None:
        continue
    if query.strip() in queries:
        continue
    generated_text_path = os.path.join(temp_data_dir, type, str(_id))
    if not os.path.exists(generated_text_path):
        os.makedirs(generated_text_path)
    with open(os.path.join(generated_text_path, 'query.txt'), 'w', encoding='utf-8') as f:
        f.write(generated_text)
    with open(os.path.join(generated_text_path, "passage1.txt"), 'w', encoding='utf-8') as f:
        f.write(data[_key][16].strip())
    with open(os.path.join(generated_text_path, "passage2.txt"), 'w', encoding='utf-8') as f:
        f.write(data[_key][17].strip())
    _id += 1
    count += 1
    if count == 50:
        break