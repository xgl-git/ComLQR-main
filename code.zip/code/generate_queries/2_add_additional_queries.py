import os
import re
import json
import csv
def extract_query_answer(text):
    query_pattern = re.search(r'Query:\s*(.*?)\n', text)
    answer_pattern = re.search(r'Answer:\s*(.*)', text)
    query = query_pattern.group(1) if query_pattern else None
    answer = answer_pattern.group(1) if answer_pattern else None
    return query, answer
base_dir = './addition_queries'
q_c_pairs = []
for file in os.listdir(base_dir):
    id_type_info = file.split('.')[0].split('_')
    LEN = len(id_type_info)
    qid = id_type_info[0]
    cids = id_type_info[1: LEN - 1]
    type = id_type_info[LEN - 1]
    file_path = os.path.join(base_dir, file)
    content = open(file_path, 'r', encoding = 'utf-8').read()
    query, answer = extract_query_answer(content)
    if query == None or answer == None:
        continue
    with open('dataset/queries.jsonl', 'a', encoding='utf-8') as f:
        data = {"_id": str(qid), "text": query.strip(), "answer": answer.strip(), "type": type}
        json.dump(data, f, ensure_ascii = False)
        f.write("\n")
    if len(cids) == 1:
        q_c_pairs.append([str(qid), str(cids[0]), '2'])
    else:
        for cid in cids:
            q_c_pairs.append([str(qid), str(cid), '1'])
qrels_path = './dataset/qrels/'
with open(os.path.join(qrels_path, 'test.tsv'), 'a', newline='', encoding='utf-8') as file:
    writer = csv.writer(file, delimiter='\t')
    for row in q_c_pairs:
        writer.writerow(row)