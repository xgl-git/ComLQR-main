python mymain.py \
    --openai_api_key kw-yaIRae0YPWIBPqIpiOALGU5NuoDBXPdIrsaGkQ6kEF635nus\
    --openai_base_url http://10.88.3.81:8502\
    --clq_data_dir ./dataset\
    --clq_corpus_file corpus.jsonl\
    --clq_query_file queries.jsonl\
