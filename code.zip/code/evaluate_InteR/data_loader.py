# data_loader.py

import os
import json
import csv
import logging # 确保 logging 被导入和配置
from tqdm.autonotebook import tqdm # 保留 tqdm
from typing import Dict, Tuple, Optional # 引入类型提示

# 配置日志记录器 (如果尚未在你的脚本中配置)
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GenericDataLoader:
    def __init__(self, data_folder: str = None, prefix: str = None, corpus_file: str = "corpus.jsonl",
                 query_file: str = "queries.jsonl",
                 qrels_folder: str = "qrels", qrels_file: str = ""):
        self.corpus: Dict[str, Dict[str, str]] = {}
        self.queries: Dict[str, Dict[str, Optional[str]]] = {} # 值现在是字典 {"text": ..., "type": ...}
        self.qrels: Dict[str, Dict[str, int]] = {}

        if prefix:
            query_file = prefix + "-" + query_file
            # qrels_folder = prefix + "-" + qrels_folder # qrels_folder 通常直接用，split 会附加到 qrels_file

        self.data_folder = data_folder if data_folder else "." # 提供一个默认值

        # 构建完整路径
        self.corpus_file = os.path.join(self.data_folder, corpus_file)
        self.query_file = os.path.join(self.data_folder, query_file)
        # qrels_folder 是 qrels 文件所在目录的名称，相对于 data_folder
        self.qrels_folder_path = os.path.join(self.data_folder, qrels_folder)
        self.qrels_file_template = qrels_file # 通常为空，split 会构成文件名

        # logger.info(f"DataLoader initialized. Corpus: {self.corpus_file}, Queries: {self.query_file}, Qrels Dir: {self.qrels_folder_path}")


    @staticmethod
    def check(fIn: str, ext: str):
        if not os.path.exists(fIn):
            # raise ValueError("File {} not present! Please provide accurate file.".format(fIn))
            logger.error("File {} not present! Please provide accurate file.".format(fIn)) # 改为日志错误
            return False # 返回False表示检查失败
        if ext and not fIn.endswith(ext): # 允许 ext 为空或 None
            # raise ValueError("File {} must be present with extension {}".format(fIn, ext))
            logger.error("File {} must be present with extension {}".format(fIn, ext))
            return False
        return True

    def _load_corpus(self):
        if not self.check(fIn=self.corpus_file, ext="jsonl"):
            return # 如果文件检查失败，则不继续加载
        logger.info("Loading Corpus from {}...".format(self.corpus_file))
        # num_lines = sum(1 for i in open(self.corpus_file, 'rb')) # 对于大文件可能较慢
        self.corpus = {}
        try:
            with open(self.corpus_file, encoding='utf8') as fIn:
                for line_num, line_content in enumerate(tqdm(fIn, desc="Loading Corpus")):
                    try:
                        data = json.loads(line_content)
                        doc_id = data.get("id") # 假设 ID 字段是 "id"
                        doc_text = data.get("text", data.get("contents", "")) # 优先 "text"，其次 "contents"
                        doc_title = data.get("title", "")

                        if doc_id is None:
                            logger.warning(f"Document at line {line_num+1} in {self.corpus_file} is missing 'id' field. Skipping.")
                            continue
                        
                        self.corpus[str(doc_id)] = {
                            "text": doc_text,
                            "title": doc_title,
                        }
                    except json.JSONDecodeError:
                        logger.error(f"Skipping invalid JSON line {line_num+1} in {self.corpus_file}: {line_content.strip()}")
        except FileNotFoundError:
            logger.error(f"Corpus file not found: {self.corpus_file}")
        if self.corpus:
            logger.info("Loaded %d Documents. Example: %s", len(self.corpus), list(self.corpus.values())[0] if self.corpus else "N/A")
        else:
            logger.warning("No documents loaded from corpus file: %s", self.corpus_file)


    def _load_queries(self):
        if not self.check(fIn=self.query_file, ext="jsonl"):
            return
        logger.info("Loading Queries from {}...".format(self.query_file))
        # num_lines = sum(1 for i in open(self.query_file, 'rb'))
        self.queries = {}
        try:
            with open(self.query_file, encoding='utf8') as fIn:
                for line_num, line_content in enumerate(tqdm(fIn, desc="Loading Queries")):
                    try:
                        data = json.loads(line_content)
                        query_id = data.get("id")      # 假设 ID 字段是 "id"
                        query_text = data.get("text")
                        query_type = data.get("type", None) # 可选的 type 字段

                        if query_id is None:
                            logger.warning(f"Query at line {line_num+1} in {self.query_file} is missing 'id' field. Skipping.")
                            continue
                        if query_text is None:
                            logger.warning(f"Query '{query_id}' in {self.query_file} is missing 'text' field. Storing as empty text.")
                            query_text = ""
                        
                        self.queries[str(query_id)] = {"text": query_text, "type": query_type}
                    except json.JSONDecodeError:
                        logger.error(f"Skipping invalid JSON line {line_num+1} in {self.query_file}: {line_content.strip()}")
        except FileNotFoundError:
            logger.error(f"Query file not found: {self.query_file}")

        if self.queries:
            logger.info("Loaded %d Queries (before qrels filtering). Example: %s", len(self.queries), list(self.queries.values())[0] if self.queries else "N/A")
        else:
            logger.warning("No queries loaded from query file: %s", self.query_file)


    def _load_qrels(self, qrels_file_path: str):
        if not self.check(fIn=qrels_file_path, ext="tsv"):
            return
        logger.info("Loading Qrels from {}...".format(qrels_file_path))
        self.qrels = {}
        try:
            with open(qrels_file_path, encoding="utf-8") as fIn:
                reader = csv.reader(fIn, delimiter="\t", quoting=csv.QUOTE_MINIMAL)
                header = next(reader, None) # 读取并跳过表头
                if header is None :
                    logger.warning(f"Qrels file {qrels_file_path} is empty or has no header. Assuming columns: query-id, corpus-id, score")
                # else:
                    # logger.info(f"Qrels header: {header}")

                for row_num, row in enumerate(tqdm(reader, desc="Loading Qrels")):
                    try:
                        if len(row) < 3:
                            logger.warning(f"Skipping malformed qrels row {row_num+2} (not enough columns) in {qrels_file_path}: {row}")
                            continue
                        query_id, corpus_id, score_str = str(row[0]), str(row[1]), row[2]
                        score = int(score_str)

                        if query_id not in self.qrels:
                            self.qrels[query_id] = {corpus_id: score}
                        else:
                            self.qrels[query_id][corpus_id] = score
                    except ValueError:
                        logger.warning(f"Skipping malformed qrels row {row_num+2} (score is not an int) in {qrels_file_path}: {row}")
                    except IndexError: # 应该被 len(row) < 3 捕获，但以防万一
                        logger.warning(f"Skipping malformed qrels row {row_num+2} (IndexError) in {qrels_file_path}: {row}")
        except FileNotFoundError:
             logger.error(f"Qrels file not found: {qrels_file_path}")
        if self.qrels:
            logger.info("Loaded Qrels for %d query IDs. Example QID: %s, Data: %s", len(self.qrels), list(self.qrels.keys())[0] if self.qrels else "N/A", list(self.qrels.values())[0] if self.qrels else "N/A")
        else:
            logger.warning("No qrels loaded from qrels file: %s", qrels_file_path)

    def load(self, split="test") -> Tuple[Dict[str, Dict[str, str]], Dict[str, Dict[str, Optional[str]]], Dict[str, Dict[str, int]]]:
        # 1. 完整加载语料库
        if not self.corpus: # 只有当 self.corpus 为空时才加载
            self._load_corpus()

        # 2. 完整加载所有查询
        if not self.queries: # 只有当 self.queries 为空时才加载
            self._load_queries()

        # 3. 构建 qrels 文件路径并加载 qrels
        # self.qrels_file_template 通常是空字符串 ""，split 用于构成文件名如 "test.tsv"
        # 如果 self.qrels_file_template 被设置了，它会作为基础文件名
        actual_qrels_filename = self.qrels_file_template if self.qrels_file_template else f"{split}.tsv"
        current_qrels_file = os.path.join(self.qrels_folder_path, actual_qrels_filename)
        
        self._load_qrels(current_qrels_file) # 加载 qrels 到 self.qrels

        # 4. 根据 qrels 筛选查询 (仅当 qrels 成功加载时)
        # 确保 self.queries 已经被 _load_queries() 填充
        if self.qrels and self.queries: # 只有在 qrels 和 queries 都加载了内容时才筛选
            filtered_queries: Dict[str, Dict[str, Optional[str]]] = {}
            num_queries_before_filter = len(self.queries)
            for qid_from_qrels in self.qrels: # qid_from_qrels 是字符串
                if qid_from_qrels in self.queries:
                    filtered_queries[qid_from_qrels] = self.queries[qid_from_qrels]
                else:
                    logger.warning(f"Query ID '{qid_from_qrels}' found in qrels but not in loaded queries from '{self.query_file}'. It will be excluded from the final query set.")
            
            self.queries = filtered_queries # 用筛选后的结果覆盖 self.queries
            logger.info("Filtered queries based on qrels. Original query count: %d. Final query count for split '%s': %d.",
                        num_queries_before_filter, split, len(self.queries))
        elif not self.qrels:
             logger.warning(f"No qrels loaded from '{current_qrels_file}'. Queries will not be filtered. Using all {len(self.queries)} loaded queries.")
        elif not self.queries:
            logger.warning(f"No queries loaded from '{self.query_file}'. Cannot filter or return queries.")


        # 日志记录最终加载情况
        logger.info("Load complete for split '%s': %d corpus docs, %d queries, qrels for %d query IDs.",
                    split, len(self.corpus), len(self.queries), len(self.qrels))
        
        if self.queries:
            logger.info("Example query data after loading: %s -> %s", list(self.queries.keys())[0], list(self.queries.values())[0])
        else:
            logger.info("No queries to show as an example after loading process.")


        return self.corpus, self.queries, self.qrels

    # 为外部直接加载特定 qrels 文件提供一个方法 (如果需要)
    def load_custom_qrels(self, qrels_file_path: str):
        self._load_qrels(qrels_file_path)
        # (可选) 如果需要，也可以在这里基于新的 qrels 筛选 self.queries
        if self.qrels and self.queries:
            filtered_queries = {qid: self.queries[qid] for qid in self.qrels if qid in self.queries}
            self.queries = filtered_queries
        return self.qrels