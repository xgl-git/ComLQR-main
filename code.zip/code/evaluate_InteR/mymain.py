# mymain.py (只显示需要修改和相关的部分)

import os
import sys
from tqdm import tqdm
import numpy as np
from time import sleep
import json
import csv
import argparse
from collections import Counter
from pyserini.search import FaissSearcher, LuceneSearcher
from pyserini.search.faiss import AutoQueryEncoder

from openai import OpenAI 

from data_loader import GenericDataLoader
from evaluate import evaluate
from utils import * 

# --- 全局变量和初始化 ---
run_path = './runs_inter'
print(f'工作目录是 {run_path}')
if not os.path.exists(run_path):
    os.makedirs(run_path)

# 与InteR中保持一致
def model_init(args):
    print(f'{format_time()} 加载 contriever 查询编码器...')
    query_encoder = AutoQueryEncoder(encoder_dir=args.encoder_path, pooling='mean')
    # print(f'{format_time()} 初始化 lucene 搜索器 (SciFact)...')

    bm25_searcher = LuceneSearcher(args.lucene_index_path)
    # print(f'{format_time()} 初始化 faiss 搜索器 (SciFact)...')

    faiss_index_path_for_searcher = args.faiss_index_path
    if os.path.isfile(args.faiss_index_path) and os.path.basename(args.faiss_index_path) == 'index':
        faiss_index_path_for_searcher = os.path.dirname(args.faiss_index_path)
    con_searcher = FaissSearcher(faiss_index_path_for_searcher, query_encoder)
    # print(f'{format_time()} 模型和索引初始化完成。')

    psg_collections = None
    if args.comode == 'rmdemo' and args.psg_collections_path and os.path.exists(args.psg_collections_path):
        print(f'{format_time()} 加载演示文集从: {args.psg_collections_path}')
        psg_collections = load_tsv(args.psg_collections_path)
    return query_encoder, bm25_searcher, con_searcher, psg_collections

def gen_query_embedding(all_emb_c, index_select, q_emb=None, ensemble=False):
    all_emb_c = np.take(all_emb_c, index_select, axis=0)
    if not ensemble:
        if q_emb is not None:
            all_emb_c = np.concatenate((all_emb_c, q_emb), axis=0)
        avg_emb_c = np.mean(all_emb_c, axis=0)
        avg_emb_c = avg_emb_c.reshape((1, len(avg_emb_c)))
        return avg_emb_c
    else:
        q_emb_expand = np.repeat(q_emb, all_emb_c.shape[0], axis=0)
        emb_cat = np.stack([all_emb_c, q_emb_expand], axis=1)
        emb_cat = np.mean(emb_cat, axis=1, keepdims=True)
        return list(emb_cat)

def merge_hit(hits_list):
    docid2scores =[]
    for hits in hits_list:
        docid2score = {}
        for hit in hits:
            docid2score[hit.docid] = hit.score
        docid2scores.append(docid2score)
    sums = Counter()
    counters = Counter()
    for itemset in docid2scores:
        sums.update(itemset)
        counters.update(itemset.keys())
    hits_ret = {x: float(sums[x])/counters[x] for x in sums.keys()}
    hits_ret = dict(sorted(hits_ret.items(), key=lambda item: item[1], reverse = True)[:1000])
    return hits_ret

def call_codex_read_api(client: OpenAI, message_for_api, llm_model_to_use: str, llm_type='chatgpt', beamsize=1, temperature=0.7, max_tokens=512):
    """
    使用传入的 OpenAI 客户端调用 LLM。
    llm_model_to_use: 传递给 API 的实际模型名称。
    message_for_api: 根据 llm_type 确定是 messages 列表还是 prompt 字符串。
    """
    num_try = 0
    get_result = False
    generated_texts = []
    max_retries = 15 # 尝试15次，没连接上证明api接口设置失败

    while not get_result and num_try < max_retries:
        try:
            if llm_type == 'chatgpt':
                response = client.chat.completions.create(
                    model=llm_model_to_use,
                    messages=message_for_api,
                    n=beamsize,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                for choice in response.choices:
                    if choice.message and choice.message.content:
                        generated_texts.append(choice.message.content.strip())
            elif llm_type == 'completion':
                # 确保 message_for_api 是一个字符串 prompt
                actual_prompt = message_for_api if isinstance(message_for_api, str) else str(message_for_api)
                response = client.completions.create(
                    model=llm_model_to_use,
                    prompt=actual_prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    n=beamsize,
                )
                for choice in response.choices:
                    if choice.text:
                        generated_texts.append(choice.text.strip())
            else:
                print(f"错误: 未知的 llm_type: {llm_type}")
                break
            get_result = True
        except Exception as e:
            num_try += 1
            print(f"OpenAI API 调用错误: {e}") # 打印实际错误
            print(f'---------调用LLM失败!!! 尝试次数 {num_try} / {max_retries} ----------')
            if num_try < max_retries:
                sleep_time = min(2**num_try, 60) # 指数退避
                print(f"等待 {sleep_time} 秒后重试...")
                sleep(sleep_time)
            else:
                print("达到最大重试次数，放弃调用。")
        
    if not get_result:
        print(f"LLM调用在{num_try}次尝试后仍然失败。返回空列表。")
    return generated_texts

def gen_context_with_llm(args, openai_client: OpenAI, topics, qrels, iter_num, prompt_template, demo_psgs=None, with_demo=False, load_ctx=False):
    qid2contexts = {}
    file_gpt_gen = f'{run_path}/{args.dataset_name_for_output}-{args.llm_model_for_filename}-gen-{args.prompt_prefix}-iter{iter_num}.jsonl'

    if load_ctx and os.path.exists(file_gpt_gen) and os.path.isfile(file_gpt_gen):
        # 读取文件
        print(f'读取缓存文件: {file_gpt_gen}')
        try:
            with open(file_gpt_gen, 'r', encoding='utf-8') as f:
                for line_num, line_content in enumerate(f):
                    try:
                        item = json.loads(line_content.strip())
                        qid_cache = str(item.get('query_id'))
                        if qid_cache:
                             qid2contexts[qid_cache] = item.get('contexts', [])
                    except json.JSONDecodeError:
                        print(f"缓存文件 {file_gpt_gen} 第 {line_num+1} 行JSON解析错误，跳过。") # 使用 print 替代 logger
            print(f"{format_time()} 加载LLM上下文完成。")
        except Exception as e:
            print(f"读取缓存文件 {file_gpt_gen} 时出错: {e}。将尝试重新生成。")
            qid2contexts = {}
    
    qids_to_generate = [qid for qid in tqdm(topics, desc='准备生成任务') if qid not in qid2contexts and qid in qrels]

    if qids_to_generate:
        print(f'共 {len(qids_to_generate)} 个查询需要新生成上下文，写入缓存文件: {file_gpt_gen}')
        write_mode = 'a' if qid2contexts and load_ctx else 'w' 
        with open(file_gpt_gen, write_mode, encoding='utf-8') as fgen:
            for qid in tqdm(qids_to_generate, desc='生成中'):
                query = topics[qid]['title']
                current_prompt_text = ""
                if with_demo and demo_psgs is not None and qid in demo_psgs and demo_psgs[qid]:
                    current_prompt_text = prompt_template.format(query=query, passages=demo_psgs[qid])
                else:
                    current_prompt_text = prompt_template.format(query=query)

                message_for_api_call: any
                if args.llm_type == 'chatgpt':
                    message_for_api_call = [
                        {"role": "system", "content": "You are a helpful assistant that provides concise and relevant passages to answer questions."},
                        {"role": "user", "content": current_prompt_text}
                    ]
                elif args.llm_type == 'completion':
                    message_for_api_call = current_prompt_text
                else:
                    print(f"错误: 未知的 args.llm_type: {args.llm_type} for qid {qid}")
                    contexts = [] # 返回空，避免错误
                    # continue

                if message_for_api_call: # 只有在消息准备好的情况下才调用
                    contexts = call_codex_read_api(
                        client=openai_client,
                        message_for_api=message_for_api_call,
                        llm_model_to_use=args.llm_model_name, # 使用命令行指定的模型名
                        llm_type=args.llm_type,
                        beamsize=args.num_ctx_gen,
                        temperature=args.temperature,
                        max_tokens=args.max_tokens
                    )
                else: # 如果 llm_type 未知
                    contexts = []

                fgen.write(json.dumps({'query_id': qid, 'query': query, 'contexts': contexts})+'\n')
                qid2contexts[qid] = contexts
    else:
        if load_ctx and qid2contexts: 
             print("所有查询的上下文均从缓存加载。")
        else: 
             print("没有需要生成上下文的查询。")
    return qid2contexts, {}

# 与InteR中main一致
def ret_demo_with_context(args, topics, qrels, qid2contexts, current_searcher, use_context=True, ret_type='de2', eval_mode=False, query_encoder_instance=None, bm25_searcher_instance=None):
    all_hits_list = []
    for id_val, qid in enumerate(tqdm(topics, desc='检索中')):
        if qid in qrels:
            query = topics[qid]['title']
            contexts = qid2contexts.get(qid, [])[:args.num_ctx_use]
            hits_for_query = []
            if 'bm2' in ret_type and bm25_searcher_instance:
                query_parts = [query] * args.num_ctx_use
                context_parts = [psg.strip().replace('\n', ' ') for psg in contexts]
                query_exp = ' '.join(query_parts + context_parts)
                hits_for_query = bm25_searcher_instance.search(query_exp, k=args.num_demo if not eval_mode else 1000)
            elif 'de2' in ret_type and query_encoder_instance and current_searcher:
                q_emb = np.array(query_encoder_instance.encode(query), ndmin=2)
                if contexts:
                    all_emb_c = [query_encoder_instance.encode(c.strip().replace('\n', ' ')) for c in contexts]
                    all_emb_c = np.array(all_emb_c)
                    if all_emb_c.size > 0:
                        num_indices = min(all_emb_c.shape[0], args.num_ctx_use)
                        indices_to_use = list(range(num_indices))
                        if indices_to_use:
                           avg_emb = gen_query_embedding(all_emb_c, indices_to_use, q_emb)
                           hits_for_query = current_searcher.search(avg_emb, k=args.num_demo if not eval_mode else 1000)
                        else:
                           hits_for_query = current_searcher.search(q_emb, k=args.num_demo if not eval_mode else 1000)
                    else:
                        hits_for_query = current_searcher.search(q_emb, k=args.num_demo if not eval_mode else 1000)
                else:
                    hits_for_query = current_searcher.search(q_emb, k=args.num_demo if not eval_mode else 1000)
            if not isinstance(hits_for_query, list):
                hits_for_query = []
            all_hits_list.append(hits_for_query)
    return all_hits_list

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # api端口设置
    parser.add_argument("--openai_base_url", type=str, default=None, help="OpenAI API 的自定义基础 URL (例如 http://10.88.3.81:8502)。如果未提供，则使用官方 OpenAI URL。")
    # --- 其他参数保持不变，但确保 llm_model_name 对应你的自定义端点 ---
    parser.add_argument("--openai_api_key", type=str, default=os.getenv("OPENAI_API_KEY"), help="OpenAI API Key.")
    parser.add_argument("--llm_type", type=str, default="chatgpt", choices=["chatgpt", "completion"], help="LLM接口类型。")
    # 关键：确保这个模型名是你自定义端点支持的，例如 "gpt-4o-mini"
    parser.add_argument("--llm_model_name", type=str, default="gpt-4o-mini", help="LLM模型名称。")
    parser.add_argument("--llm_model_for_filename", type=str, default="custom_gpt4o_mini", help="用于缓存文件名的模型标识。")
    # ... (其他所有参数定义保持不变，包括 seed, eval_bm25_direct, load_ctx, num_ctx_gen, 等)
    parser.add_argument("--seed", type=int, default=500)
    parser.add_argument("--eval_bm25_direct", action="store_true", help="直接评估 BM25 性能。")
    parser.add_argument("--load_ctx", action="store_true", help="如果提供此参数，则尝试加载已缓存的LLM上下文。")
    parser.add_argument("--num_ctx_gen", type=int, default=3, help="LLM为每个查询生成的上下文数量。")
    parser.add_argument("--num_ctx_use", type=int, default=2, help="实际使用的LLM生成的上下文数量。")
    parser.add_argument("--num_demo", type=int, default=3, help="演示样例检索的数量。")
    parser.add_argument("--temperature", type=float, default=0.7, help="LLM 生成温度。")
    parser.add_argument("--max_tokens", type=int, default=256, help="LLM 生成最大token数。")
    parser.add_argument("--prompt_prefix", type=str, default="scifact_custom_pro2", help="用于LLM提示或缓存文件名的前缀。")
    parser.add_argument("--comode", type=str, default="scifact_custom_default", help="操作模式。")
    parser.add_argument("--encoder_path", type=str, default="/remote-home/yinzhitao/InteR/facebook_con", help="查询编码器模型路径。")
    parser.add_argument("--lucene_index_path", type=str, default="./indexes/scifact_lucene_index", help="Lucene索引路径。")
    parser.add_argument("--faiss_index_path", type=str, default="./indexes/scifact_embedding/index", help="Faiss索引文件路径。")
    parser.add_argument("--psg_collections_path", type=str, default=None, help="演示文集路径 (对于SciFact通常不需要)。")
    parser.add_argument("--clq_data_dir", type=str, default="./dataset", help="数据集根目录。")
    parser.add_argument("--clq_corpus_file", type=str, default="corpus.jsonl", help="语料库文件名。")
    parser.add_argument("--clq_query_file", type=str, default="queries.jsonl", help="查询文件名。")
    parser.add_argument("--clq_qrels_dir", type=str, default="qrels", help="Qrels子目录名。")
    parser.add_argument("--clq_split", type=str, default="test", help="数据集划分。")
    parser.add_argument("--dataset_name_for_output", type=str, default="scifact_test", help="用于输出文件的名称。")

    args = parser.parse_args()
    # 检查端口并设置output file
    if args.openai_base_url: 
        args.llm_model_for_filename = f"custom_{args.llm_model_name.replace('/', '_')}"
        args.dataset_name_for_output = f"scifact_{args.clq_split}_custom_llm"
    else:
        args.llm_model_for_filename = args.llm_model_name.replace('/', '_')
        args.dataset_name_for_output = f"scifact_{args.clq_split}"
    # 检查api设置
    if not args.openai_api_key:
        print("错误: OpenAI API Key 未设置。请通过 --openai_api_key 参数或 OPENAI_API_KEY 环境变量提供。")
        sys.exit(1)
    
    client_args = {"api_key": args.openai_api_key}
    if args.openai_base_url:
        client_args["base_url"] = args.openai_base_url
        print(f"使用自定义 OpenAI Base URL: {args.openai_base_url}")
    
    # 设置agent
    openai_client = OpenAI(**client_args)


    setup_seed(args.seed)
    # 初始化逻辑
    query_encoder, bm25_searcher, con_searcher, psg_collections = model_init(args)
    #加载数据
    print(f"{format_time()} 从以下位置加载数据: {args.clq_data_dir}，划分: {args.clq_split}")
    data_loader = GenericDataLoader(data_folder=args.clq_data_dir,
                                    corpus_file=args.clq_corpus_file,
                                    query_file=args.clq_query_file,
                                    qrels_folder=args.clq_qrels_dir)
    corpus_dict_loaded, clq_queries_dict, qrels = data_loader.load(split=args.clq_split)
    topics = {}
    for qid, q_data in clq_queries_dict.items():
        if qid in qrels:
            topics[qid] = {'title': q_data['text']}
    all_qids = list(topics.keys())
    print(f"{format_time()} 已加载 {len(corpus_dict_loaded)} 个文档, {len(topics)} 个查询, qrels for {len(qrels)} queries.")

    # 直接使用bm25进行评估
    if args.eval_bm25_direct:
        
        print(f"{format_time()} 评估直接 BM25 检索...")
        bm25_all_hits = []
        for qid in tqdm(all_qids, desc="BM25检索中"):
            query_text = topics[qid]['title']
            hits = bm25_searcher.search(query_text, k=1000)
            bm25_all_hits.append(hits)
        results_for_bm25_eval = {}
        for i, qid_str in enumerate(all_qids):
            current_hits_list = bm25_all_hits[i]
            scores_for_qid = {}
            for hit_obj in current_hits_list:
                scores_for_qid[str(hit_obj.docid)] = float(hit_obj.score)
            results_for_bm25_eval[str(qid_str)] = scores_for_qid
        k_values_eval = [1, 3, 5, 10, 20, 100]
        ndcg, map_score, recall, precision = evaluate(qrels, results_for_bm25_eval, k_values_eval)
        print(f"BM25 在 {args.clq_split} 划分上的直接评估结果:")
        print("NDCG:", ndcg); print("MAP:", map_score); print("Recall:", recall); print("Precision:", precision)
    else: # 使用InteR方法
        num_iter = 2
        demo_psgs = None
        final_all_hits = None
        for iter_count in range(0, num_iter):
            if iter_count == 0:
                usr_prompt_template = "Please write a passage to answer the question\nQuestion: {query}\nPassage:"
            else:
                usr_prompt_template = "Give a question \"{query}\" and its possible answering passages \n{passages}\nplease write a correct answering passage."

            print(f"{format_time()} 迭代-{iter_count}: 使用 LLM 生成上下文")
            should_load_cache = args.load_ctx # 如果命令行提供 --load_ctx，则为 True
            qid2contexts, _ = gen_context_with_llm(args, openai_client, topics, qrels, iter_count, usr_prompt_template, demo_psgs, with_demo=iter_count > 0, load_ctx=should_load_cache)

            if not qid2contexts and iter_count == 0 : # 如果第一次迭代就没有生成任何上下文（可能是API调用一直失败）
                print("错误：第一次迭代未能生成任何LLM上下文，无法继续。请检查LLM调用。")
                break


            if iter_count > 0:
                print(f"{format_time()} 迭代-{iter_count}: 使用 BM25 (上下文增强) 进行检索以进行评估")
                final_all_hits = ret_demo_with_context(args, topics, qrels, qid2contexts,
                                                       current_searcher=None,
                                                       bm25_searcher_instance=bm25_searcher,
                                                       query_encoder_instance=query_encoder,
                                                       use_context=True, ret_type='bm2', eval_mode=True)
                break
            
            print(f"{format_time()} 迭代-{iter_count}: 使用稠密检索 (Contriever + 上下文) 检索 demo_psgs")
            all_hits_for_demo = ret_demo_with_context(args, topics, qrels, qid2contexts,
                                                      current_searcher=con_searcher,
                                                      query_encoder_instance=query_encoder,
                                                      bm25_searcher_instance=bm25_searcher,
                                                      use_context=True, ret_type='de2', eval_mode=False)
            demo_psgs = {}
            for i, qid_str in enumerate(all_qids):
                if i < len(all_hits_for_demo) and all_hits_for_demo[i] is not None:
                    current_demo_hits = all_hits_for_demo[i]
                    temp_psgs_text = []
                    for hit in current_demo_hits[:args.num_demo]:
                        doc_id_str = str(hit.docid)
                        if doc_id_str in corpus_dict_loaded:
                            temp_psgs_text.append(corpus_dict_loaded[doc_id_str]['text'].strip())
                    if temp_psgs_text:
                        demo_psgs[qid_str] = '\n'.join([f"{k+1}. {c}" for k, c in enumerate(temp_psgs_text)])
                    else:
                        demo_psgs[qid_str] = "No relevant demonstration passages found from current corpus."
                else:
                     demo_psgs[qid_str] = "No hits for demonstration for this query."
            
            if num_iter == 1:
                print(f"{format_time()} 仅迭代一次，评估当前稠密检索结果。")
                final_all_hits = ret_demo_with_context(args, topics, qrels, qid2contexts,
                                                       current_searcher=con_searcher, 
                                                       query_encoder_instance=query_encoder,
                                                       bm25_searcher_instance=bm25_searcher,
                                                       use_context=True, ret_type='de2', eval_mode=True)
                break
        
        if final_all_hits:
            # 对结果进行评估
            results_for_eval = {}
            for i, qid_str in enumerate(all_qids): 
                if i < len(final_all_hits) and final_all_hits[i] is not None:
                    current_hits_list = final_all_hits[i]
                    scores_for_qid = {}
                    for hit_obj in current_hits_list:
                        scores_for_qid[str(hit_obj.docid)] = float(hit_obj.score)
                    results_for_eval[str(qid_str)] = scores_for_qid
                else:
                    results_for_eval[str(qid_str)] = {} 
            k_values_eval = [1, 3, 5, 10, 20, 100]
            ndcg, map_score, recall, precision = evaluate(qrels, results_for_eval, k_values_eval)
            final_iter_display = iter_count if iter_count > 0 else ( (num_iter -1) if num_iter > 1 else 0)
            eval_method_name = f"迭代方法 (iter {final_iter_display}, llm_model {args.llm_model_name} @ {args.openai_base_url if args.openai_base_url else 'OpenAI_default'})" # 更新评估名称
            print(f"{eval_method_name} 在 {args.clq_split} 划分上的评估结果:")
            print("NDCG:", ndcg); print("MAP:", map_score); print("Recall:", recall); print("Precision:", precision)
        else:
            print("没有最终的命中结果可供评估。")