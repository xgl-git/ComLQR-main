import nltk

import os
download_dir = os.path.expanduser('/root/nltk_data') # 下载到用户主目录下的nltk_data
if not os.path.exists(download_dir):
    os.makedirs(download_dir)
if download_dir not in nltk.data.path:
    nltk.data.path.append(download_dir)
print(f"NLTK data will be downloaded to: {nltk.data.path}")

try:
    print("Downloading 'stopwords'...")
    nltk.download('stopwords') # 您可以去掉 quiet=True 来查看下载进度
    print("'stopwords' downloaded successfully or already present.")
except Exception as e:
    print(f"Error downloading 'stopwords': {e}")

try:
    print("Downloading 'punkt'...")
    nltk.download('punkt') # 您可以去掉 quiet=True 来查看下载进度
    print("'punkt' downloaded successfully or already present.")
except Exception as e:
    print(f"Error downloading 'punkt': {e}")