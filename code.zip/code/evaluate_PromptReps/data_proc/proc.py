# 由于dataset.py中处理数据集要求每一行数据中有一个docid表示passage id
# 但sciFact中并没有该属性，因此本文件是将corpus.jsonl中的_id属性变成docid

import json
import os

def modify_corpus_id_field(input_file_path, output_file_path, old_id_field="_id", new_id_field="docid"):
    """
    读取一个JSON Lines文件，修改每一行JSON对象中的ID字段名，并将结果写入新的JSON Lines文件。

    参数:
    input_file_path (str): 输入的原始JSON Lines文件路径。
    output_file_path (str): 输出的修改后JSON Lines文件路径。
    old_id_field (str): 原始文件中ID字段的名称。
    new_id_field (str): 新文件中ID字段的名称。
    """
    try:
        with open(input_file_path, 'r', encoding='utf-8') as infile, \
             open(output_file_path, 'w', encoding='utf-8') as outfile:
            
            line_number = 0
            for line in infile:
                line_number += 1
                try:
                    # 解析当前行JSON
                    data_object = json.loads(line.strip())
                    
                    # 检查旧的ID字段是否存在
                    if old_id_field in data_object:
                        # 获取旧ID字段的值
                        id_value = data_object[old_id_field]
                        # 删除旧的ID字段
                        del data_object[old_id_field]
                        # 添加新的ID字段及其值
                        data_object[new_id_field] = id_value
                    else:
                        print(f"警告: 第 {line_number} 行没有找到字段 '{old_id_field}'。该行未作修改直接写入。")
                    
                    # 将修改后的JSON对象写回新文件，并换行
                    outfile.write(json.dumps(data_object, ensure_ascii=False) + '\n')
                    
                except json.JSONDecodeError:
                    print(f"警告: 第 {line_number} 行不是有效的JSON格式。该行被跳过。")
                except Exception as e:
                    print(f"处理第 {line_number} 行时发生错误: {e}。该行被跳过。")
                    
        print(f"文件处理完成。修改后的文件已保存到: {output_file_path}")

    except FileNotFoundError:
        print(f"错误: 输入文件 '{input_file_path}' 未找到。")
    except Exception as e:
        print(f"发生了一个错误: {e}")

if __name__ == "__main__":
    # --- 配置您的文件路径 ---
    # 原始 corpus.jsonl 文件路径 (根据您 run.sh 中的设置)
    original_corpus_file = "./datasets/queries.jsonl" #
    
    # 修改后新文件的保存路径 (建议先保存到新文件，确认无误后再替换原文件)
    # 例如，在原文件名后加上 "_modified"
    base, ext = os.path.splitext(original_corpus_file)
    modified_corpus_file = f"{base}_modified{ext}"
    
    # 您也可以选择直接覆盖原文件，但请务必先备份！
    # modified_corpus_file = original_corpus_file 
    # 如果要覆盖，请确保您已备份原文件，或者先将上面的行注释掉，用这行。
    # 强烈建议：如果选择覆盖，请在运行前手动备份 original_corpus_file。

    print(f"将从 '{original_corpus_file}' 读取数据...")

    
    old_id_field_name = "text"
    new_id_field_name = "query"
    print(f"将把 '{old_id_field_name}' 字段修改为 '{new_id_field_name}'...")
    print(f"修改后的数据将保存到 '{modified_corpus_file}'...")
    modify_corpus_id_field(original_corpus_file, modified_corpus_file, old_id_field_name, new_id_field_name)

    # --- 后续操作建议 ---
    # 1. 检查 'corpus_modified.jsonl' 文件内容是否符合预期。
    # 2. 如果确认无误，您可以选择：
    #    a. 将 'corpus_modified.jsonl' 重命名为 'corpus.jsonl' (覆盖原文件)。
    #       os.rename(modified_corpus_file, original_corpus_file)
    #    b. 或者修改您的 run.sh 脚本中的 CORPUS_FILE_PATH 指向新的 'corpus_modified.jsonl' 文件。
    #       例如: CORPUS_FILE_PATH=./datasets/scifact/corpus_modified.jsonl
    #
    # 为了安全起见，下面的重命名操作默认是注释掉的。
    if input(f"是否要将 '{modified_corpus_file}' 重命名覆盖 '{original_corpus_file}'? (yes/no): ").lower() == 'yes':
        try:
            os.rename(modified_corpus_file, original_corpus_file)
            print(f"文件已重命名为: {original_corpus_file}")
        except Exception as e:
            print(f"重命名文件时出错: {e}")
    else:
        print(f"请手动检查 '{modified_corpus_file}'。如果满意，您可以手动替换原文件或更新脚本中的路径。")