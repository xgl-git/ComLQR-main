BASE_MODEL=/remote-home/yinzhitao/Meta-Llama-3-8B-Instruct # 或者您选择的模型
# 注意：OUTPUT_DIR的路径现在反映了这是本地scifact数据
OUTPUT_DIR=outputs/${BASE_MODEL}/scifact_local
# # 创建输出目录，如果它们不存在
mkdir -p ${OUTPUT_DIR}/dense
mkdir -p ${OUTPUT_DIR}/sparse
mkdir -p ${OUTPUT_DIR}/results

NUM_AVAILABLE_GPUS=1 # 根据您的GPU数量调整
CORPUS_FILE_PATH=datasets/corpus.jsonl

for i in $(seq 0 $((NUM_AVAILABLE_GPUS-1)))
do
CUDA_VISIBLE_DEVICES=${i} python encode.py \
        --output_dir=temp \
        --model_name_or_path ${BASE_MODEL} \
        --tokenizer_name ${BASE_MODEL} \
        --per_device_eval_batch_size 32 \
        --passage_max_len 512 \
        --normalize \
        --bf16 \
        --dataset_name json \
        --dataset_path ${CORPUS_FILE_PATH} \
        --dense_output_dir ${OUTPUT_DIR}/dense \
        --sparse_output_dir ${OUTPUT_DIR}/sparse \
        --passage_prefix prompts/${BASE_MODEL}/passage_prefix.txt \
        --passage_suffix prompts/${BASE_MODEL}/passage_suffix.txt \
        --cache_dir cache_models \
        --dataset_cache_dir cache_datasets \
        --dataset_number_of_shards ${NUM_AVAILABLE_GPUS} \
        --dataset_shard_index ${i} &
done
wait

SPARSE_INPUT_DIR="outputs//remote-home/yinzhitao/Meta-Llama-3-8B-Instruct/scifact_local/sparse/"
INDEX_OUTPUT_DIR="outputs//remote-home/yinzhitao/Meta-Llama-3-8B-Instruct/scifact_local/sparse/index"

# 创建索引输出目录的父目录（如果尚不存在）
mkdir -p "$(dirname "$INDEX_OUTPUT_DIR")"


python -m pyserini.index.lucene \
  --collection JsonVectorCollection \
  --input ${SPARSE_INPUT_DIR} \
  --index ${INDEX_OUTPUT_DIR} \
  --generator DefaultLuceneDocumentGenerator \
  --threads 16 \
  --impact --pretokenized

# 假设您的 BASE_MODEL 和 OUTPUT_DIR 与 run.sh 中一致
# 您需要为 SciFact 数据集准备一个查询文件 (queries.jsonl)
# 假设您的 SciFact 查询文件路径是: ./datasets/scifact/queries.jsonl
# 并且其格式与 PromptRepsEncodeDataset 期望的查询格式一致（包含 query_id 和 query 字段）

QUERY_FILE_PATH="datasets/queries.jsonl"
# DATASET_NAME_FOR_EVAL="scifact" # 用于评估脚本中指定qrels，或在search.py中指定split
# 根据README，Tevatron/beir 数据集的 split 通常是 test, train, dev
DATASET_SPLIT_FOR_SEARCH="test" # 或者您的SciFact查询对应的split

# search.py 的参数与 encode.py 类似，但需要指定passage_reps和sparse_index
# 以及 --encode_is_query
python search.py \
    --output_dir=temp \
    --model_name_or_path ${BASE_MODEL} \
    --tokenizer_name ${BASE_MODEL} \
    --batch_size 32 \
    --threads 16 \
    --query_max_len 512 \
    --passage_max_len 512 \
    --normalize \
    --bf16 \
    --dataset_name json \
    --dataset_path ${QUERY_FILE_PATH} \
    --query_prefix prompts/${BASE_MODEL}/query_prefix.txt \
    --query_suffix prompts/${BASE_MODEL}/query_suffix.txt \
    --cache_dir cache_models \
    --encode_is_query \
    --dataset_cache_dir cache_datasets \
    --passage_reps ${OUTPUT_DIR}/dense/ \
    --sparse_index ${OUTPUT_DIR}/sparse \
    --alpha 0.5 \
    --depth 1000 \
    --save_dir ${OUTPUT_DIR}/results/ \
    --use_gpu \
    --remove_query

QRELS_NAME="beir-v1.0.0-scifact-test"
python -m pyserini.eval.trec_eval -c -m recall.100,1000 -m ndcg_cut.10 ${QRELS_NAME} ${OUTPUT_DIR}/results/rank.dense.trec
python -m pyserini.eval.trec_eval -c -m recall.100,1000 -m ndcg_cut.10 ${QRELS_NAME} ${OUTPUT_DIR}/results/rank.sparse.trec
python -m pyserini.eval.trec_eval -c -m recall.100,1000 -m ndcg_cut.10 ${QRELS_NAME} ${OUTPUT_DIR}/results/rank.hybrid.trec