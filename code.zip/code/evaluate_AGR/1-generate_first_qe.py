import tqdm
import os
import re
import random
import json
# from vllm import LLM, SamplingParams
from llama_cpp import Llama
import multiprocessing
# os.environ["CUDA_VISIBLE_DEVICES"]="0,1"


# 设置Mistral-7B-Instruct-v02模型的本地路径
# model_path = '/Users/yangchen/Desktop/my_AGR/Mistral-7B-Instruct-v02_cli'
model_path = '/Users/yangchen/Desktop/my_AGR/Mistral-7B-Instruct-v0.2-GGUF/mistral-7b-instruct-v0.2.Q5_K_M.gguf'

def main():
    # 获取CPU核心数用于设置线程数，使用物理核心数的2倍
    num_threads = multiprocessing.cpu_count()
    print(f"Using {num_threads} threads for inference")
    # 初始化Llama模型，设置模型路径和线程数
    model = Llama(
        model_path=model_path,
        n_threads=num_threads,  # 使用获取的线程数
        n_batch=512,  # 设置批处理大小
        use_mlock=True,  # 使用内存锁定以提高性能,
        verbose=False,  # 禁用详细日志输出
    )

    # 定义输入问题文件和输出结果文件的路径
    question_file = '/Users/yangchen/Desktop/my_AGR/ComLogicQuery/dataset/queries_sample.jsonl'  # 修改为JSONL格式文件路径
    output_file = 'output_test/first-qe.txt'
    print(f"Start generate: {question_file}\n")
    with open(output_file, 'a') as fw:  # 以追加模式打开输出文件
        # 读取JSONL格式的输入文件
        queries = []
        with open(question_file, 'r') as f:
            for line in f:
                queries.append(json.loads(line))

        # 使用tqdm创建带进度条的循环处理每个查询
        for i in tqdm.trange(0, len(queries)):
            query_obj = queries[i]
            q_base = query_obj['text']  # 从JSONL中提取text字段作为查询文本
            print(q_base)

            # 第一阶段：关键短语分析
            # 构建提示模板，引导模型识别问题中的关键短语和专有名词
            instruction_kp_analyze = """[INST]Please note that this is a brand new conversation start. When responding to the following questions, disregard all previous interactions and context.
Question: {query}

When analyzing a phrase, first consider if the phrase could be a proper noun, such as the title of a song, movie, book, or other work. If it is a common phrase or doesn't immediately appear to be a title, then proceed to analyze its grammatical structure as a standard phrase. However, if there is a possibility that the phrase is a title, treat it as a proper noun and analyze it in that context.

Do not attempt to explain or answer the question, just provide the key phrases.

Expected Output:
"Key Phrases Output": key phrases in "{query}"

Output:[/INST]""".format(query=q_base.strip())
            # # 配置采样参数：低温度(0.2)保证输出稳定性，最大生成150个token，设置重复惩罚避免冗余
            # sampling_params = SamplingParams(temperature=0.2, max_tokens=150, repetition_penalty=1.1)
            # # 调用模型进行关键短语分析
            # output = llm_base.generate(instruction_kp_analyze, sampling_params)
            # # 获取模型输出的关键短语分析结果
            # answer_kp_analysis = output[0].outputs[0].text
            output = model(
                instruction_kp_analyze,
                max_tokens=150,
                temperature=0.2,
                repeat_penalty=1.1,
                echo=False,
            )
            answer_kp_analysis = output["choices"][0]["text"]
            print(answer_kp_analysis)
            # 处理输出文本：移除换行符并去除首尾空白
            answer_kp_analysis = answer_kp_analysis.replace('\n',' ').strip()

            # 第二阶段：问题分析
            # 构建问题分析提示，将第一阶段的关键短语结果作为输入
            instruction_analyze = """[INST]Question: {query}
Key Phrases in query:{answer_kp_analysis}

Analyze the question carefully. Determine what type of information is being asked for. Consider the most direct way to find this information. If the question is about identifying something or someone, focus on the specific details provided. Avoid assumptions or interpretations beyond what is explicitly asked. Provide a clear and concise answer based on the analysis.

Do not attempt to explain or answer the question, just provide the Question Analysis.

Expected Output:
"Question Analysis": Question Analysis based on Key Phrases

Output:[/INST]""".format(query=q_base.strip(),answer_kp_analysis=answer_kp_analysis)
            # # 使用与第一阶段相同的采样参数
            # sampling_params = SamplingParams(temperature=0.2, max_tokens=150, repetition_penalty=1.1)
            # # 调用模型进行问题分析
            # output = llm_base.generate(instruction_analyze, sampling_params)
            # # 获取模型输出的问题分析结果
            # answer_analysis = output[0].outputs[0].text
            output = model(
                instruction_analyze,
                max_tokens=150,
                temperature=0.2,
                repeat_penalty=1.1,
                echo=False
            )
            answer_analysis = output["choices"][0]["text"]
            print(answer_analysis)
            # 处理输出文本：移除换行符并去除首尾空白
            answer_analysis = answer_analysis.replace('\n',' ').strip()

            # 第三阶段：答案生成
            # 构建答案生成提示，结合原始问题和前两阶段的分析结果
            instruction_extend = """[INST]Question: {query}
Question analysis: {answer_analysis}

Based on the analysis and your available knowledge, create a possibly correct and concise answer that directly answers the question "{query}".

Expected Output:
"Answer": answer with a detailed context
Output:
"Answer":[/INST]""".format(query=q_base.strip(), answer_analysis=answer_analysis)
            # # 配置采样参数：较高温度(0.8)增加输出多样性，生成30个不同答案，每个最多100个token
            # sampling_params = SamplingParams(temperature=0.8, max_tokens=100, repetition_penalty=1.1, n=30)
            # # 调用模型生成多个可能的答案
            # output = llm_base.generate(instruction_extend, sampling_params)
            # 生成多个答案
            result_extend = []
            for _ in range(10):
                output = model(
                    instruction_extend,
                    max_tokens=100,
                    temperature=0.8,
                    repeat_penalty=1.1,
                    echo=False
                )
                response = output["choices"][0]["text"]
                response = response.replace('\n', ' ').strip()
                if response.startswith("Answer:"):
                    response = response[len("Answer:"):].strip()
                result_extend.append(response)
            # # 从30个生成结果中选取前10个，处理格式（移除换行符和"Answer:"前缀）
            # result_extend += [output[0].outputs[i].text.replace('\n',' ').strip().strip('Answer: ') for i in range(10)]
            # 随机打乱答案顺序，增加多样性
            random.shuffle(result_extend)
            print(result_extend)

            # 将生成的答案写入输出文件
            for it in result_extend:
                item = [query_obj['_id'], it.replace('\n',' ').strip()]  # 使用JSONL中的_id字段而不是索引
                fw.write('\t'.join(item) + '\n')  # 以制表符分隔写入文件
                fw.flush()  # 立即刷新文件缓冲区，确保数据写入磁盘

if __name__ == '__main__':
    # 当脚本作为主程序运行时，调用main函数
    # 这解决了多进程启动的问题
    main()
