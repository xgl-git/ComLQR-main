python -m pyserini.index.lucene \
  --collection JsonCollection \
  --generator DefaultLuceneDocumentGenerator \
  --input /Users/yangchen/Desktop/my_AGR/AGR/collection_json_sample \
  --index /Users/yangchen/Desktop/my_AGR/AGR/index_dir \
  --threads 8 \
  --storePositions --storeDocvectors --storeRaw