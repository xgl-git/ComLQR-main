## `1-generate_first_qe.py` 

重写query，得到查询扩展文件 `first-qe.json`

## 需要准备 TSV 文件

格式如下

| id  | contents | title |
| --- | -------- | ----- |
| XXX | XXX      | XXX   |

## 需要准备JsonCollection文件夹

格式如下

```
folder
	|
	|--- 1.json
	|--- 2.json
	...
```

每个json内容如下

```json
{  
  "id": "XXXX",  
  "contents": "XXXX",  
  "title": "XXXXX"  
}
```

## 2-cerate_index.sh

根据JsonCollection文件夹，构建 Lucene 索引

## 需要准备qa.json

从第一步的到的`first-qe.json` 转换

格式如下

```json
[
	{
		"question": "XXXXXX",
		"answers": [
			"answer1",
			"answer2",
		]
	},
	{
		"question": "XXXXXX",
		"answers": [
			"answer1",
			"answer2",
		]
	},
]
```

## 3-sparse_retriever.py

进行检索，演示命令如下

```bash
export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-21.jdk/Contents/Home  
export JVM_PATH=/Library/Java/JavaVirtualMachines/jdk-21.jdk/Contents/Home/lib/server/libjvm.dylib  
  
python sparse_retriever.py \  
--index_name /Users/yangchen/Desktop/my_AGR/AGR/index_dir \  
--qa_file /Users/yangchen/Desktop/my_AGR/AGR/output_test/qa.json \  
--ctx_file /Users/yangchen/Desktop/my_AGR/AGR/passages.tsv \  
--output_dir /Users/yangchen/Desktop/my_AGR/AGR/output_test \  
--n-docs 10 \  
--num_threads 4 \  
--no_wandb \  
--dedup \  
--pyserini_cache ./bm25_cache
```