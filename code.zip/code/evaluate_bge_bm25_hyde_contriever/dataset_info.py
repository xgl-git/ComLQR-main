import os
import csv
import json


base_dir = './dataset'
qid2cid = {}
with open(os.path.join(base_dir, 'qrels', 'test.tsv'), 'r', newline='', encoding='utf-8') as file:
    csv_reader = csv.reader(file, delimiter='\t')
    header = next(csv_reader)
    for row in csv_reader:
        qid, cid, score = row
        if qid not in qid2cid:
            qid2cid[qid] = []
            qid2cid[qid].append(cid)
        else:
            qid2cid[qid].append(cid)
count1 = 0
count2 = 0
count3 = 0
for qid in qid2cid:
    # print(len(qid2cid[qid]))
    if len(qid2cid[qid]) == 1:
        count1 += 1
    if len(qid2cid[qid]) == 2:
        count2 += 1
    if len(qid2cid[qid]) == 3:
        count3 += 1
print("Number of Queries corresponding to one relevant passage", count1)
print("Number of Queries corresponding to two relevant passages", count2)
print("Number of Queries corresponding to three relevant passages", count3)
print()
num_type_queries = {"1p": 0, "2p":0, "3p":0, "2i":0, "3i":0, "pi": 0,
           "ip": 0, "2u": 0, "up": 0, "2in": 0, "3in": 0, "inp": 0, "pin": 0, "pni": 0}
# num_type_queries_1 ={"3p_1": 0, "3p_2": 0, "3p_3": 0, "3i_1": 0, "3i_2": 0, "3i_3":0,
#             "3in_1": 0, "3in_2": 0, "3in_3":0, "pin_1": 0, "pin_2":0, "pin_3": 0}

num_queries = 0
len_queries = 0
with open(os.path.join(base_dir, 'queries.jsonl'), 'r', encoding='utf-8') as file:
    for line in file.readlines():
        data = json.loads(line)
        num_queries += 1
        len_queries += len(data["text"].split(' '))
        query_type = data['type']
        type = query_type.split('_')[0]
        num_type_queries[type] += 1
        # if query_type in num_type_queries_1:
        #     num_type_queries_1[query_type] += 1
print("Number of each queries:")
for type in num_type_queries:
    print(type, num_type_queries[type])
print()

# for type in num_type_queries_1:
#     print(type, num_type_queries_1[type])
# print()

print("Average length of queries", len_queries/num_queries)
print("Number of queries", num_queries)
print()

num_passages = 0
len_passages = 0
with open(os.path.join(base_dir, 'corpus.jsonl'), 'r', encoding='utf-8') as file:
    for line in file.readlines():
        data = json.loads(line)
        num_passages += 1
        len_passages += len(data["text"].split(' '))
print("Average length of passages", len_passages/num_passages)
print("Number of passages", num_passages)
