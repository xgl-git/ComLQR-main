import argparse


def init_model():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='', type=str)
    parser.add_argument('--storage', default='', type=str)
    parser.add_argument('--dataset', default='', type=str)
    parser.add_argument('--model_path', default='', type=str)
    parser.add_argument('--device', default='', type=str)
    parser.add_argument('--api_key', default='', type=str)
    return parser
