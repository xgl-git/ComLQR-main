from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings
from init_parameter import init_model
from llama_index.core import VectorStoreIndex
from data_loader import GenericDataLoader
from llama_index.core import Document

parser = init_model()

args = parser.parse_args()
Settings.embed_model = HuggingFaceEmbedding(model_name = args.model_path, device = args.device)
data_path = args.data

corpus, queries, qrels = GenericDataLoader(data_path).load(split="test")

texts = []
corpus_dict = {}
for doc_id in corpus:
    texts.append(corpus[doc_id]["text"].strip())
    corpus_dict[corpus[doc_id]["text"].strip()] = doc_id
documents = [Document(text=t) for t in texts]
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.retrievers import VectorIndexRetriever
splitter = SentenceSplitter(chunk_size = 10000)
index = VectorStoreIndex.from_documents(documents, transformations=[splitter])
retriever = VectorIndexRetriever(index=index, similarity_top_k=100)
results = {"1p":{}, "2p":{}, "3p":{}, "2i":{}, "3i":{}, "pi": {},
           "ip": {}, "2u": {}, "up": {}, "2in": {}, "3in": {}, "inp": {}, "pin": {}, "pni": {}, "total": {}}
fine_grained_results ={"3p_1":{}, "3p_2":{}, "3p_3":{}, "3i_1":{}, "3i_2":{}, "3i_3":{},
            "3in_1":{}, "3in_2":{}, "3in_3":{}, "pin_1":{}, "pin_2":{}, "pin_3":{}}
import time
total_time = 0
cnt = 0
for query_id in queries:
    query_type = queries[query_id]['type']
    query = queries[query_id]['text']
    start_time = time.time()
    nodes = retriever.retrieve(query)
    scores = {}
    for node in nodes:
        doc_id = corpus_dict[node.text]
        scores[doc_id] = node.score
    end_time = time.time()
    cnt += 1
    total_time += end_time - start_time
    if cnt == 10:
        print(total_time/cnt)
    type = query_type.split('_')[0]
    results[type][query_id] = scores
    results["total"][query_id] = scores
    if query_type in fine_grained_results:
        fine_grained_results[query_type][query_id] = scores
k_values = [1, 3, 5, 10, 100]
from evaluate import *

for _key in results:
    ndcg, _map, recall, precision = evaluate(qrels, results[_key], k_values)
    print(_key, _map, recall)
for _key in fine_grained_results:
    ndcg, _map, recall, precision = evaluate(qrels, fine_grained_results[_key], k_values)
    print(_key, _map, recall)