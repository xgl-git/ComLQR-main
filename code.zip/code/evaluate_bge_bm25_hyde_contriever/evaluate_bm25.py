from data_loader import GenericDataLoader
from init_parameter import init_model
from llama_index.core import Document
import os
parser = init_model()

args = parser.parse_args()


data_path = args.data
corpus, queries, qrels = GenericDataLoader(data_path).load(split="test")
texts = []
corpus_dict = {}
for doc_id in corpus:
    texts.append(corpus[doc_id]["text"].strip())
    corpus_dict[corpus[doc_id]["text"].strip()] = doc_id
documents = [Document(text=t) for t in texts]
from llama_index.core.node_parser import SentenceSplitter

# initialize node parser
splitter = SentenceSplitter(chunk_size=10000)

nodes = splitter.get_nodes_from_documents(documents)
from llama_index.retrievers.bm25 import BM25Retriever
import Stemmer

# We can pass in the index, docstore, or list of nodes to create the retriever
bm25_retriever = BM25Retriever.from_defaults(
    nodes=nodes,
    similarity_top_k=100,
    # Optional: We can pass in the stemmer and set the language for stopwords
    # This is important for removing stopwords and stemming the query + text
    # The default is english for both
    stemmer=Stemmer.Stemmer("english"),
    language="en",
)
results = {"1p":{}, "2p":{}, "3p":{}, "2i":{}, "3i":{}, "pi": {},
           "ip": {}, "2u": {}, "up": {}, "2in": {}, "3in": {}, "inp": {}, "pin": {}, "pni": {}, "total": {}}
fine_grained_results ={"3p_1":{}, "3p_2":{}, "3p_3":{}, "3i_1":{}, "3i_2":{}, "3i_3":{},
            "3in_1":{}, "3in_2":{}, "3in_3":{}, "pin_1":{}, "pin_2":{}, "pin_3":{}}
import time
total_time = 0
cnt = 0
for query_id in queries:
    query_type = queries[query_id]['type']
    query = queries[query_id]['text']
    start_time = time.time()
    nodes = bm25_retriever.retrieve(query)
    scores = {}
    for node in nodes:
        doc_id = corpus_dict[node.text]
        scores[doc_id] = node.score
    end_time = time.time()
    total_time += (end_time - start_time)
    cnt += 1
    type = query_type.split('_')[0]
    results[type][query_id] = scores
    results["total"][query_id] = scores
    if query_type in fine_grained_results:
        fine_grained_results[query_type][query_id] = scores
print(total_time/cnt)
k_values = [1, 3, 5, 10, 100]
from evaluate import *

for _key in results:
    ndcg, _map, recall, precision = evaluate(qrels, results[_key], k_values)
    print(_key, ndcg)
for _key in fine_grained_results:
    ndcg, _map, recall, precision = evaluate(qrels, fine_grained_results[_key], k_values)
    print(_key, ndcg)